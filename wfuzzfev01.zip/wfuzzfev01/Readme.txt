WFuzzFe v0.1
JGUI-mized by Aung Khant <http://yehg.net/lab>

WFuzz v1.4
Carlos del ojo &  Christian Martorella 
http://edge-security.com


Requirements
==============
1. JRE 1.5 >=
    http://java.sun.com
2. Python 2.5 >=
    http://python.org

Required Python Packages
======================
Pycurl
http://pycurl.sourceforge.net/download/
WConio
http://newcenturycomputers.net/projects/wconio.html
