Google Hacker (HTA Application)

Released to public only at 9:43 AM Thursday, September 13, 2007. 
I forgot :)

Description:
============
A small light-weight Windows HTA Application useful as your regular google hacking tool on Windows platform. With comprehensive google search form that includes sensitive google hacking keywords. Right from application, capable of saving search strings on disk. Capable of directly modifying files  : 1.sitedomains.txt	2.sensitive_words.txt	3.prefixes.txt	4.file_types.txt	5.fav_words.txt. 

Installation:
============
Run GoogleHack.hta

Change Logs:
============
Fixed some coding  Sept 17 2007


To create desktop shortcut,double_click on "CreateShortCut.vbs".

That's it.

Any questions ?

visit : http://forum.flashband.net

Thanks

Aung Khant (d0ubl3_h3lix)
shiningstarak [at] gmail [dot] com
Myanmar