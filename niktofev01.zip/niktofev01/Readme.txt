NiktoFE v.01
c0ded by Aung Khant <http://yehg.net/lab>

Nikto version  2.02/2.03     -     cirt.net

To run NiktoFE
============
Windows:
Open run.cmd or  double-click NiktoFE.jar on Windows 

*Nix
Invoke run.sh after (chmod u+x) 

To update nikto
=============
Simply run:
update_nikto.cmd or
update_nikto.sh after (chmod u+x) 

Requirements:
==============
Java 1.5 >=
http://java.sun.com

PERL: http://www.cpan.org/
Or 
ActiveState Perl: http://www.activestate.com/

LibWhisker: http://www.wiretrip.net/
OpenSSL: http://www.openssl.org/

